let header = '<header><nav><ul><li><a href="/">Home</a></li><li><a href="/create">Add Car</a></li><li><a href="/all">All Cars</a></li><li><a href="/stats">Statistics</a></li></ul></nav></header>'

module.exports = header
