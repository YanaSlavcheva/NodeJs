let scripts = '<script src="/scripts/bootstrap.min.js"></script>'

module.exports = scripts
