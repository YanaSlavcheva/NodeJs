let styles = '<link rel="stylesheet" type="text/css" href="/content/styles/site.css"><link rel="stylesheet" type="text/css" href="/content/styles/vendor/bootstrap-responsive.min.css"><link rel="stylesheet" type="text/css" href="/content/styles/vendor/bootstrap.min.css">'

module.exports = styles
