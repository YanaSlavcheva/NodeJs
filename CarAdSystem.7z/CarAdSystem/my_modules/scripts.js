let scripts = '<script src="/scripts/jquery-3.1.1.min.js"></script><script src="/scripts/bootstrap.min.js"></script>'

module.exports = scripts
