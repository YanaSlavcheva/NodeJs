let header = '<header class="row"><h1 class="span6 text-left">Car Ad System</h1><nav class="span6 text-right"><ul><li><a href="/">Home</a></li><li><a href="/create">Add Car</a></li><li><a href="/all">All Cars</a></li><li><a href="/stats">Statistics</a></li></ul></nav></header>'

module.exports = header
