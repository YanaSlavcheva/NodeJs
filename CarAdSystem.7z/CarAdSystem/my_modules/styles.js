let styles = '<link rel="stylesheet" type="text/css" media="screen" href="/content/styles/vendor/bootstrap.min.css"><link rel="stylesheet" type="text/css" media="screen" href="/content/styles/vendor/bootstrap-responsive.min.css"><link rel="stylesheet" type="text/css" href="/content/styles/site.css">'

module.exports = styles
